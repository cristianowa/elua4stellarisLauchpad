//*****************************************************************************
//
//! \addtogroup nb_uart_api
//! @{
//
//*****************************************************************************

//*****************************************************************************
//
//! The 9-bit UART API utilises the UART interrupt for proper operation.  If
//! this NB_USER_INT_HANDLER macro is defined, then the NB_UserIntHandler()
//! function will be called in the 9-Bit UART ISR.  This function allows the
//! user to add their own customized code to the UART interrupt.
//!
//! NOTE: The NB_UserIntHandler() function will be called in an \b interrupt
//! \b context.
//
//*****************************************************************************
#define NB_USER_INT_HANDLER

//*****************************************************************************
//
//! User UART Interrupt handler
//!
//! The 9-Bit UART API requires the use of the UART interrupt and this function
//! allows the user to add their own routine in the UART ISR.  This function
//! will be called if the NB_USER_INT_HANDLER macro is defined, and will occur
//! after the 9-bit UART API has already executed its code.  This means that
//! if data was received after a valid address, it will already be stored in
//! the receive buffer prior to this function being called.
//! 
//! NOTE: This function will be called in an \b interrupt \b context.
//!
//! \return None.
//
//*****************************************************************************
void
NB_UserIntHandler(void)
{
}

//*****************************************************************************
//
// Close the Doxygen group.
//! @}
//
//*****************************************************************************
