//*****************************************************************************
//
// nb_uart.h - Defines functions and Macros for the software 9-bit UART
// add-on.
//
// Copyright (c) 2005-2010 Texas Instruments Incorporated.  All rights reserved.
// Software License Agreement
// 
// Texas Instruments (TI) is supplying this software for use solely and
// exclusively on TI's microcontroller products. The software is owned by
// TI and/or its suppliers, and is protected under applicable copyright
// laws. You may not combine this software with "viral" open-source
// software in order to form a larger program.
// 
// THIS SOFTWARE IS PROVIDED "AS IS" AND WITH ALL FAULTS.
// NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. TI SHALL NOT, UNDER ANY
// CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
// DAMAGES, FOR ANY REASON WHATSOEVER.
// 
// This is part of revision xxxx of the 9-bit UART Example.
//
//*****************************************************************************

//*****************************************************************************
//
//! \addtogroup nb_uart_api
//! @{
//
//*****************************************************************************

#ifndef __UART_NINE_BIT_H__
#define __UART_NINE_BIT_H__

#ifdef __cplusplus
extern "C"
{
#endif

//*****************************************************************************
//
//! Receive buffer size configuration.
//
//*****************************************************************************
#define RX_BUFFER_SIZE 16

//*****************************************************************************
//
//! Value that is passed to NB_UARTConfigSetExpClk() to configure the UART for
//! one stop bit.
//
//*****************************************************************************
#define UART_CONFIG_STOP_ONE    0x00000000

//*****************************************************************************
//
//! Value that is passed to NB_UARTConfigSetExpClk() to configure the UART for
//! two stop bits.
//
//*****************************************************************************
#define UART_CONFIG_STOP_TWO    0x00000008

//*****************************************************************************
//
// API Function prototypes
//
//*****************************************************************************
extern void NB_UARTConfigSetExpClk(unsigned long ulBase,
                                   unsigned long ulUARTClk,
                                   unsigned long ulBaud,
                                   unsigned long ulStop);
extern void NB_UARTConfigGetExpClk(unsigned long ulBase,
                                   unsigned long ulUARTClk,
                                   unsigned long *pulBaud,
                                   unsigned long *pulConfig);
extern long NB_UARTDataGetNonBlocking(unsigned long ulBase);
extern long NB_UARTDataGet(unsigned long ulBase);
extern void NB_UARTDataPut(unsigned long ulBase, unsigned char ucData);
extern tBoolean NB_UARTDataPutNonBlocking(unsigned long ulBase, unsigned char ucData);
extern void NB_UARTAddrPut(unsigned long ulBase, unsigned char ucAddress);
extern tBoolean NB_UARTAddrPutNonBlocking(unsigned long ulBase, unsigned char ucAddress);
extern tBoolean NB_UARTBusy(unsigned long ulBase);
extern void NB_UARTEnable(unsigned long ulBase);
extern void NB_UARTDisable(unsigned long ulBase);
extern tBoolean NB_UARTDataAvail(unsigned long ulBase);
extern void NB_UARTAddressSet(unsigned long ulBase, unsigned char ulAddress);
extern unsigned long NB_UARTAddressGet(unsigned long ulBase);
extern void NB_UserIntHandler(void);

#ifdef __cplusplus
}
#endif

#endif

//*****************************************************************************
//
// Close the Doxygen group.
//! @}
//
//*****************************************************************************
