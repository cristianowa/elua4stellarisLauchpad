//*****************************************************************************
//
// sw01280.c - Sample application using the 9-bit UART add-on.
//
// Copyright (c) 2005-2010 Texas Instruments Incorporated.  All rights reserved.
// Software License Agreement
// 
// Texas Instruments (TI) is supplying this software for use solely and
// exclusively on TI's microcontroller products. The software is owned by
// TI and/or its suppliers, and is protected under applicable copyright
// laws. You may not combine this software with "viral" open-source
// software in order to form a larger program.
// 
// THIS SOFTWARE IS PROVIDED "AS IS" AND WITH ALL FAULTS.
// NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. TI SHALL NOT, UNDER ANY
// CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
// DAMAGES, FOR ANY REASON WHATSOEVER.
// 
// This is part of revision xxxx of the 9-bit UART Example.
//
//*****************************************************************************

#include "inc/hw_gpio.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/sysctl.h"
#include "utils/uartstdio.h"
#include "nb_uart.h"

//*****************************************************************************
//
//! \addtogroup example_list
//! <h1>9-bit UART example</h1>
//!
//! This is a simple application that uses the 9-bit UART software API to setup
//! the UART, set the UART address, and setup the user ISR function.  This
//! example will echo the received data back out the 9-bit UART, and print out
//! the character that was received via a terminal window (standard UART).
//! The configuration used for the 9-bit UART is 115,200 8-sticky-1.
//!
//! NOTE: This example also shows how to use the NB_UserIntHandler() function.
//! For this function to be called you need to globaly define the macro
//! NB_USER_INT_HANDLER in your compiler or in the nb_uart.h file.
//!
//! This example uses the following peripherals and I/O signals.  You must
//! review these and change as needed for your own board:
//! - UART0 peripheral (for VCOM)
//! - UART1 peripheral (for 9-bit UART)
//! - GPIO Port A peripheral (for UART0 pins)
//! - GPIO Port D peripheral (for UART1 pins)
//! - UART0RX - PA0
//! - UART0TX - PA1
//! - UART1RX - PD0
//! - UART1TX - PD1
//!
//
//*****************************************************************************

//*****************************************************************************
//
// The error routine that is called if the driver library encounters an error.
//
//*****************************************************************************
#ifdef DEBUG
void
__error__(char *pcFilename, unsigned long ulLine)
{
}
#endif

//*****************************************************************************
//
// Empty Rx FIFO return value.
//
//*****************************************************************************
#define NO_DATA_AVAILABLE   -1

//*****************************************************************************
//
// Source Address.
//
//*****************************************************************************
#define UART_SOURCE_ADDRESS 0x55

//*****************************************************************************
//
// Destination Address.
//
//*****************************************************************************
#define UART_DEST_ADDRESS   0x14

//*****************************************************************************
//
// Variable to keep track of how many interrupts have been received.
//
//*****************************************************************************
static unsigned long ulNumOfInt = 0;

//*****************************************************************************
//
// My ISR to be called in the UART ISR.
//
//*****************************************************************************
void
NB_UserIntHandler(void)
{
    //
    // Increment the interrupt count variable.
    //
    ulNumOfInt++;
}

//*****************************************************************************
//
// This function sets up UART0 to be used for a console to display information
// as this example is running.
//
//*****************************************************************************
void
InitConsole(void)
{
    //
    // Enable GPIO port A which is used for UART0 pins.
    // TODO: change this to whichever GPIO port you are using.
    //
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

    //
    // Configure the pin muxing for UART0 functions on port A0 and A1.
    // This step is not necessary if your part does not support pin muxing.
    // TODO: change this to select the port/pin you are using.
    //
    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);

    //
    // Select the alternate (UART) function for these pins.
    // TODO: change this to select the port/pin you are using.
    //
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    //
    // Initialize the UART for console I/O.
    //
    UARTStdioInit(0);
}

//******************************************************************************
//
// A simple example application that uses the 9-bit UART to echos characters
// whenever one is received.
//
//******************************************************************************
int
main(void)
{
    long lRxData;

    //
    // Set the clocking to run directly from the external crystal/oscillator.
    // TODO: The SYSCTL_XTAL_ value must be changed to match the value of the
    // crystal on your board.
    //
    SysCtlClockSet(SYSCTL_SYSDIV_1 | SYSCTL_USE_OSC | SYSCTL_OSC_MAIN |
                   SYSCTL_XTAL_16MHZ);

    //
    // Set up the serial console to use for displaying messages.  This is
    // just for this example program and is not needed for 9-bit UART
    // operation.
    //
    InitConsole();

    //
    // Print introduction message to the terminal.
    //
    UARTprintf("9-Bit UART Example Code\n\n");

    //
    // Enable the UART1 hardware.
    //
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART1);

    //
    // Enable the GPIO port UART1 uses.
    //
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);

    //
    // Configure the pin mux for the GPIO pins.  This step is only necessary
    // if your part supports pin muxing.
    // TODO: change this to select the ports/pins you are using.
    //
    GPIOPinConfigure(GPIO_PD0_U1RX);
    GPIOPinConfigure(GPIO_PD1_U1TX);

    //
    // Set the GPIO pins to UART functionality.
    // TODO: change this to select the ports/pins you are using.
    //
    GPIOPinTypeUART(GPIO_PORTD_BASE, GPIO_PIN_1 | GPIO_PIN_0);

    //
    // Configure the UART1 with the system clock, 115200 baud and one stop bit.
    // The NB_UARTConfigSetExpClk function will call NB_UARTEnable(), which
    // will configure the Rx interrupt and initialize the software FIFO.
    //
    // Note: The NB_UARTConfigSetExpClk function automatically sets the data
    //       size to 8-bits and configures the parity mode to stick parity.
    //
    NB_UARTConfigSetExpClk(UART1_BASE, SysCtlClockGet(), 115200,
                           UART_CONFIG_STOP_ONE);

    //
    // Set the 9-bit UART source address.
    //
    NB_UARTAddressSet(UART1_BASE, UART_SOURCE_ADDRESS);

    //
    // Enable processor interrupts once the 9-bit UART is configured and the
    // address is set.
    //
    IntMasterEnable();

    //
    // Send out the 9-bit UART destination address.
    //
    NB_UARTAddrPut(UART1_BASE, UART_DEST_ADDRESS);

    //
    // Echo the characters as they are received.
    //
    while(1)
    {
        //
        // Get the next character from the UART using the non-blocking function.
        //
        lRxData = NB_UARTDataGetNonBlocking(UART1_BASE);

        //
        // If there was a valid character received then print it and echo it.
        //
        if(lRxData != NO_DATA_AVAILABLE)
        {
            //
            // Print out the character received and number of interrupts on
            // UART0.
            //
            UARTprintf("\rCharacter Received: %c  -  Number of interrupts: %d",
                       (unsigned char)lRxData, ulNumOfInt);

            //
            // Echo the character using the blocking put.
            //
            NB_UARTDataPut(UART1_BASE, (unsigned char)lRxData);
        }			 
    }
}
