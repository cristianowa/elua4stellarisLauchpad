//*****************************************************************************
//
// nb_uart.c - Driver for the software 9-bit UART add-on.
//
// Copyright (c) 2005-2010 Texas Instruments Incorporated.  All rights reserved.
// Software License Agreement
//
// Texas Instruments (TI) is supplying this software for use solely and
// exclusively on TI's microcontroller products. The software is owned by
// TI and/or its suppliers, and is protected under applicable copyright
// laws. You may not combine this software with "viral" open-source
// software in order to form a larger program.
//
// THIS SOFTWARE IS PROVIDED "AS IS" AND WITH ALL FAULTS.
// NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. TI SHALL NOT, UNDER ANY
// CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
// DAMAGES, FOR ANY REASON WHATSOEVER.
//
// This is part of revision xxxx of the 9-bit UART Example.
//
//*****************************************************************************

//*****************************************************************************
//
//! \addtogroup nb_uart_api 9-Bit UART API Definitions
//! @{
//
//*****************************************************************************

#include "inc/hw_types.h"
#include "inc/hw_uart.h"
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "driverlib/debug.h"
#include "driverlib/interrupt.h"
#include "driverlib/uart.h"
#include "nb_uart.h"

//*****************************************************************************
//
// Eight bit data mask used to mask the incoming data and address characters.
//
//*****************************************************************************
#define LS_BYTE_MASK 0x00FF

//*****************************************************************************
//
// Mask for the parity error flag.  This mask is used to check the parity error
// flag on the data returned from the UART receive register.
//
//*****************************************************************************
#define PARITY_ERROR_BIT 0x0200

//*****************************************************************************
//
// Receive buffer variables.
//
//*****************************************************************************
static unsigned long g_ulRxBuffer[RX_BUFFER_SIZE];
static unsigned long *g_pulRxBufferHead, *g_pulRxBufferTail;
static unsigned long g_ulRxBufferCount;

//*****************************************************************************
//
// Global variable to store the data received by the UART.
//
//*****************************************************************************
static unsigned long g_ulRxChar;

//*****************************************************************************
//
// Flag used by the interrupt to indicate and remember an address match.
//
//*****************************************************************************
static unsigned long g_ulAddressMatchFlag;

//*****************************************************************************
//
// Variable used to store the base address of the UART hardware module.
// This is primarily used by the interrupt handler to know which Rx register
// to get the data from.
//
//*****************************************************************************
static unsigned long g_ulUARTBase;

//*****************************************************************************
//
// Variable used to store the programmable UART address.
//
//*****************************************************************************
static unsigned char g_ucUARTAddress;

//*****************************************************************************
//
//! Handles the adding of data to the receive character buffer.
//!
//! \param ulData is the character to be added to the RX buffer.
//!
//! Add data to the receive buffer and increment place holder.
//! This function is called by the \b NB_UARTRcvCharIntHandler ISR.
//!
//! \return Returns \b true if the data is accepted, and \b false
//! if there is no space left in the buffer.
//
//*****************************************************************************
static tBoolean
RxBufferAdd(unsigned long ulData)
{
    tBoolean bRetCode;

    //
    // Default to failing unless there is space.
    //
    bRetCode = false;

    //
    // Check for space in TX buffer.
    //
    if( g_ulRxBufferCount < RX_BUFFER_SIZE)
    {
        //
        // There was space available.
        //
        *g_pulRxBufferHead++ = ulData;

        //
        // Increment the buffer count.
        //
        g_ulRxBufferCount += 1;

        //
        // Check for wrap around.
        //
        if(g_pulRxBufferHead == (g_ulRxBuffer + RX_BUFFER_SIZE))
        {
            //
            // Wrap around.
            //
            g_pulRxBufferHead = g_ulRxBuffer;
        }
        bRetCode = true;
    }

    return(bRetCode);
}

//*****************************************************************************
//
//! Handles the removal of data to the receive character buffer.
//!
//! Removes data to the receive buffer and decrements place holder.
//!
//! \return none.
//
//*****************************************************************************
static long
RxBufferRemove(void)
{
    long lReturnChar;

    //
    // Default to no characters present.
    //
    lReturnChar = -1;

    //
    // Check is buffer is already empty.
    //
    if(g_ulRxBufferCount > 0)
    {
        //
        // Get character
        //
        lReturnChar = *(long*)g_pulRxBufferTail;

        //
        // Increment the tail.
        //
        g_pulRxBufferTail++;

        //
        // Decrement count.
        //
        g_ulRxBufferCount--;

        //
        // Check for wrap around.
        //
        if(g_pulRxBufferTail == (g_ulRxBuffer + RX_BUFFER_SIZE))
        {
            //
            // Wrap around.
            //
            g_pulRxBufferTail = g_ulRxBuffer;
        }
    }

    return lReturnChar;
}

//*****************************************************************************
//
//! Sets the configuration of a UART.
//!
//! \param ulBase is the base address of the UART port.
//! \param ulUARTClk is the rate of the clock supplied to the UART module.
//! \param ulBaud is the desired baud rate.
//! \param ulStop is the number of stop bits.
//!
//! This function will configure the UART for operation in the specified data
//! format.  The baud rate is provided in the \e ulBaud parameter and the
//! number of stop bits is provided in the \e ulStop parameter.
//!
//! The \e ulStop parameter specifies the number of stop bits.
//! \b UART_CONFIG_STOP_ONE and \b UART_CONFIG_STOP_TWO to select one or two
//! stop bits respectively.
//!
//! The peripheral clock will be the same as the processor clock.  This will be
//! the value returned by SysCtlClockGet(), or it can be explicitly hard coded
//! if it is constant and known (to save the code/execution overhead of a call
//! to SysCtlClockGet()).
//!
//! This function calls the DriverLib API version of the UARTConfigSetExpClk()
//! API with the required 9-bit UART configuration.
//!
//! \return None.
//
//*****************************************************************************
void
NB_UARTConfigSetExpClk(unsigned long ulBase, unsigned long ulUARTClk,
                       unsigned long ulBaud, unsigned long ulStop)
{
    //
    // Check the arguments.
    //
    ASSERT((ulStop == UART_CONFIG_STOP_ONE) ||
           (ulStop == UART_CONFIG_STOP_TWO));

    ASSERT(UARTBaseValid(ulBase));

    //
    // Call the UARTConfigSetExpClk from the DriverLib API.  This is done to
    // properly initialize the data length to 8 and the parity to "Stick One".
    //
    UARTConfigSetExpClk(ulBase, ulUARTClk, ulBaud, (ulStop |
                         UART_CONFIG_WLEN_8 | UART_CONFIG_PAR_ONE));

    //
    // Start the UART.
    //
    NB_UARTEnable(ulBase);
}

//*****************************************************************************
//
//! Gets the current configuration of a UART.
//!
//! \param ulBase is the base address of the UART port.
//! \param ulUARTClk is the rate of the clock supplied to the UART module.
//! \param pulBaud is a pointer to storage for the baud rate.
//! \param pulConfig is a pointer to storage for the data format.
//!
//! The baud rate and data format for the UART is determined, given an
//! explicitly provided peripheral clock (hence the ExpClk suffix).  The
//! returned baud rate is the actual baud rate; it may not be the exact baud
//! rate requested or an ``official'' baud rate.  The data format returned in
//! \e pulConfig is enumerated the same as the \e ulConfig parameter of
//! UARTConfigSetExpClk().
//!
//! The peripheral clock will be the same as the processor clock.  This will be
//! the value returned by SysCtlClockGet(), or it can be explicitly hard coded
//! if it is constant and known (to save the code/execution overhead of a call
//! to SysCtlClockGet()).
//!
//! This function calls the DriverLib API function UARTConfigGet().
//!
//! \return None.
//
//*****************************************************************************
void
NB_UARTConfigGetExpClk(unsigned long ulBase, unsigned long ulUARTClk,
                       unsigned long *pulBaud, unsigned long *pulConfig)
{
    //
    // Call the DriverLib API version of UARTConfigGetExpClk().
    //
    UARTConfigGetExpClk(ulBase, ulUARTClk, pulBaud, pulConfig);
}

//*****************************************************************************
//
//! Enables transmitting and receiving.
//!
//! \param ulBase is the base address of the UART port.
//!
//! Sets the UARTEN, TXE, and RXE bits.  This function also enables the UART
//! receive interrupt which is required for the 9-bit UART add-on.
//!
//! \return None.
//
//*****************************************************************************
void
NB_UARTEnable(unsigned long ulBase)
{
    //
    // Check the arguments.
    //
    ASSERT(UARTBaseValid(ulBase));

    //
    // Enable the UART interrupt on the processor (NVIC).  This will be based
    // on which UART hardware you choose.
    //
    if(ulBase == UART0_BASE)
    {
        IntEnable(INT_UART0);
    }
    else if(ulBase == UART1_BASE)
    {
        IntEnable(INT_UART1);
    }

    //
    // Enable the UART Rx interrupt.  Since the FIFOs are disabled, the
    // interrupt will occur every time data is received.
    //
    UARTIntEnable(ulBase, UART_INT_RX);

    //
    // Disable the UART FIFO.  The UART Tx and Rx FIFOs must be disabled for
    // the 9-bit UART code to work.  This is because every time data is
    // received we have to check the current state parity bit.  The only way
    // to guarantee that we get the interrupt every time we receive data is to
    // disable the hardware FIFOs.
    //
    UARTFIFODisable(ulBase);

    //
    // Initialize the variables used for the software Receive Buffer.
    //
    g_pulRxBufferHead = g_ulRxBuffer;
    g_pulRxBufferTail = g_ulRxBuffer;
    g_ulRxBufferCount = 0;

    //
    // Initialize the address match flag to false.  This flag indicates that
    // there is an address match.  The setting and clearing of this flag is
    // handled in the receive interrupt.
    //
    g_ulAddressMatchFlag = false;

    //
    // Save the UART base.
    //
    g_ulUARTBase = ulBase;

    //
    // Enable RX, TX, and the UART.
    //
    HWREG(ulBase + UART_O_CTL) |= (UART_CTL_UARTEN | UART_CTL_TXE |  
                                   UART_CTL_RXE);
}

//*****************************************************************************
//
//! Disables transmitting and receiving.
//!
//! \param ulBase is the base address of the UART port.
//!
//! This function calls the original UART API function UARTDisable() which
//! clears the UARTEN, TXE, and RXE bits, then waits for the end of
//! transmission of the current character.  This function also disables the
//! receive interrupt.
//!
//! \return None.
//
//*****************************************************************************
void
NB_UARTDisable(unsigned long ulBase)
{
    //
    // Check the arguments.
    //
    ASSERT(UARTBaseValid(ulBase));

    //
    // Disable the UART Rx interrupt.
    //
    UARTIntDisable(ulBase, UART_INT_RX);

    //
    // Call the DriverLib API version of UARTDisable().
    //
    UARTDisable(ulBase);
}

//*****************************************************************************
//
//! Determines if there are any characters in the receive buffer.
//!
//! \param ulBase is the base address of the UART port.
//!
//! This function returns a flag indicating whether or not there is data
//! available in the receive buffer.
//!
//! \return Returns \b true if there is data in the receive buffer, and
//! \b false if there is no data in the receive buffer.
//
//*****************************************************************************
tBoolean
NB_UARTDataAvail(unsigned long ulBase)
{
    //
    // Check the arguments.
    //
    ASSERT(UARTBaseValid(ulBase));

    //
    // Check if there are any entries are in the Rx buffer.
    //
    return((g_ulRxBufferCount) ? true : false);
}

//*****************************************************************************
//
//! Receives a character from the specified port.
//!
//! \param ulBase is the base address of the UART port.
//!
//! Gets a character from the receive buffer for the specified port.
//!
//! \return Returns the character read from the specified port, cast as a
//! \e long.  A \b -1 will be returned if there are no characters present in
//! the receive buffer.
//
//*****************************************************************************
long
NB_UARTDataGetNonBlocking(unsigned long ulBase)
{
    //
    // Check the arguments.
    //
    ASSERT(UARTBaseValid(ulBase));

    //
    // If there are any characters available.
    //
    return(RxBufferRemove());
}

//*****************************************************************************
//
//! Waits for a character from the specified port.
//!
//! \param ulBase is the base address of the UART port.
//!
//! Gets a character from the receive buffer for the specified port.  If there
//! are no characters available, this function will wait until a character is
//! received before returning.
//!
//! \return Returns the character read from the specified port, cast as an
//! \e long.
//
//*****************************************************************************
long
NB_UARTDataGet(unsigned long ulBase)
{
    //
    // Check the arguments.
    //
    ASSERT(UARTBaseValid(ulBase));

    //
    // Wait until there is a character available.
    //
    while(!NB_UARTDataAvail(ulBase))
    {
    }

    //
    // Return character.
    //
    return(RxBufferRemove());
}

//*****************************************************************************
//
//! Waits to send a data character from the specified port.
//!
//! \param ulBase is the base address of the UART port.
//! \param ucData is the character to be transmitted.
//!
//! Sends the character \e ucData to the transmit register.  This function will
//! wait until there is space in the transmit register available before
//! returning.  Data is sent by using parity to add a '0' as the most
//! significant bit of the UART bit stream.
//!
//! \return None.
//
//*****************************************************************************
void
NB_UARTDataPut(unsigned long ulBase, unsigned char ucData)
{
    //
    // Check the arguments.
    //
    ASSERT(UARTBaseValid(ulBase));

    //
    // Check if the EPS bit is clear.  If the EPS bit is clear, set it to
    // configure the parity as "Stick Zero".  We will also wait for the UART
    // busy flag to clear, which makes sure ALL the bits have shifted out of
    // the Tx register before changing the parity bit.  We do this to avoid
    // the case of sending data with a parity of "Stick One" (i.e. address)
    // and have the parity setting change to "Stick Zero" (i.e. data) before
    // all the bits have been shifted out of the Tx register.  If the EPS bit
    // is set, do nothing.
    //
    if(((~HWREG(ulBase + UART_O_LCRH)) & UART_LCRH_EPS))
    {
        //
        // This bit tells us whether all transmitted bytes have cleared the
        // transmitter hardware.  If false is returned, the transmit register
        // is empty and all bits of the last transmitted character, including
        // all stop bits, have left the hardware shift register.
        //
        while(NB_UARTBusy(ulBase))
        {
        }

        //
        // Set parity to "Stick Zero" by setting the EPS bit.  This call makes
        // sure that stick parity is enabled i.e the SPS and PEN bits in UART
        // Line Control register (UARTLCRH) are both '1'.
        //
        HWREG(ulBase + UART_O_LCRH) |= HWREG(ulBase + UART_O_LCRH) |
                                       (UART_LCRH_EPS | UART_LCRH_SPS |
                                        UART_LCRH_PEN);
    }

    //
    // Write the 8-bit data using the blocking write function.  The parity
    // configured above will now send a '0', which will appear as the most
    // significant bit of the data.  This function will not return until the
    // data has been put in the Tx register.  The "blocking" put function is
    // used because the FIFOs have been disabled for 9-bit UART operation.
    //
    UARTCharPut(ulBase, ucData);
}

//*****************************************************************************
//
//! Waits to send an address character from the specified port.
//!
//! \param ulBase is the base address of the UART port.
//! \param ucAddress is the address to be transmitted.
//!
//! Sends the character \e ucAddress to the transmit register. This function
//! will wait until there is space in the transmit register available before
//! returning.  An address is sent by using parity to add a '1' as the most
//! significant bit of the UART bit stream.
//!
//! \return None.
//
//*****************************************************************************
void
NB_UARTAddrPut(unsigned long ulBase, unsigned char ucAddress)
{
    //
    // Check the arguments.
    //
    ASSERT(UARTBaseValid(ulBase));

    //
    // Check if the EPS bit is set.  If the EPS bit is set, clear it to
    // configure the parity as "Stick One".  We will also wait for the UART
    // busy flag to clear, which makes sure ALL the bits have shifted out of
    // the Tx register before changing the parity bit.  We do this to avoid
    // the case of sending data with a parity of "Stick Zero" (i.e. data)
    // and have the parity setting change to "Stick One" (i.e. address) before
    // all the bits have been shifted out of the Tx register.  If the EPS bit
    // is clear, do nothing.
    //
    if(HWREG(ulBase + UART_O_LCRH) & UART_LCRH_EPS)
    {
        //
        // This bit tells us whether all transmitted bytes have cleared the
        // transmitter hardware.  If false is returned, the transmit register
        // is empty and all bits of the last transmitted character, including
        // all stop bits, have left the hardware shift register.
        //
        while(NB_UARTBusy(ulBase))
        {
        }

        //
        // Set parity to "Stick One" by clearing the EPS bit.  This call makes
        // sure that stick parity is enabled i.e the SPS and PEN bits in UART
        // Line Control register (UARTLCRH) are both '1'.
        //
        HWREG(ulBase + UART_O_LCRH) = (HWREG(ulBase + UART_O_LCRH) &
                                       (~UART_LCRH_EPS)) | (UART_LCRH_SPS |
                                        UART_LCRH_PEN);
    }

    //
    // Write the 8-bit address using the blocking write function.  The parity
    // configured above will now send a '1', which will appear as the most
    // significant bit of the data.  This function will not return until the
    // data has been put in the Tx register.  The "blocking" put function is
    // used because the FIFOs have been disabled for 9-bit UART operation.
    //
    UARTCharPut(ulBase, ucAddress);
}

//*****************************************************************************
//
//! Sends a data character from the specified port if the UART Tx register is
//! empty.
//!
//! \param ulBase is the base address of the UART port.
//! \param ucData is the character to be transmitted.
//!
//! Sends the character \e ucData to the transmit register.  This function
//! will return if there is no space in the transmit register.  Data is sent by
//! using parity to add a '0' as the most significant bit of the UART bit
//! stream.
//!
//! \return Returns \b true if the data is accepted, and \b false
//! if there is no space in transmit register.
//
//*****************************************************************************
tBoolean
NB_UARTDataPutNonBlocking(unsigned long ulBase, unsigned char ucData)
{
    //
    // Check the arguments.
    //
    ASSERT(UARTBaseValid(ulBase));

    //
    // Check if the UART is busy transferring.
    //
    if(NB_UARTBusy(ulBase))
    {
        return false;
    }
    else
    {
        //
        // Check if the EPS bit is clear.  If the EPS bit is clear, set it to
        // configure the parity as "Stick Zero".  We will also wait for the
        // UART busy flag to clear, which makes sure ALL the bits have shifted
        // out of the Tx register before changing the parity bit.  We do this
        // to avoid the case of sending data with a parity of "Stick One"
        // (i.e. address) and have the parity setting change to "Stick Zero"
        // (i.e. data) before all the bits have been shifted out of the Tx
        // register.  If the EPS bit is set, do nothing.
        //
        if(((~HWREG(ulBase + UART_O_LCRH)) & UART_LCRH_EPS))
        {
            //
            // Set parity to "Stick Zero" by setting the EPS bit.  This call
            // makes sure that stick parity is enabled i.e the SPS and PEN bits
            // in UART Line Control register (UARTLCRH) are both '1'.
            //
            HWREG(ulBase + UART_O_LCRH) |= HWREG(ulBase + UART_O_LCRH) |
                                           UART_LCRH_EPS | UART_LCRH_SPS |
                                           UART_LCRH_PEN;
        }

        //
        // Write the 8-bit data to the transmit register.
        //
        HWREG(ulBase + UART_O_DR) = ucData;

        //
        // Return Success.
        //
        return true;
    }
}

//*****************************************************************************
//
//! Sends an address character from the specified port if the UART Tx register
//! is empty.
//!
//! \param ulBase is the base address of the UART port.
//! \param ucAddress is the address to be transmitted.
//!
//! Sends the character \e ucAddress to the transmit register.  This function
//! will return if there is no space in the transmit register.  An address is
//! sent by using  parity to add a '1' as the most significant bit of the
//! UART bit stream.
//!
//! \return Returns \b true if the data is accepted, and \b false
//! if there is no space in transmit register.
//
//*****************************************************************************
tBoolean
NB_UARTAddrPutNonBlocking(unsigned long ulBase, unsigned char ucAddress)
{
    //
    // Check the arguments.
    //
    ASSERT(UARTBaseValid(ulBase));

    //
    // Check if the UART is busy transferring.
    //
    if(NB_UARTBusy(ulBase))
    {
        return false;
    }
    else
    {
        //
        // Check if the EPS bit is set.  If the EPS bit is set, clear it to
        // configure the parity as "Stick One".  We will also wait for the UART
        // busy flag to clear, which makes sure ALL the bits have shifted out
        // of the Tx register before changing the parity bit.  We do this to
        // avoid the case of sending data with a parity of "Stick Zero"
        // (i.e. data) and have the parity setting change to "Stick One"
        // (i.e. address) before all the bits have been shifted out of the Tx
        // register.  If the EPS bit is clear, do nothing.
        //
        if(HWREG(ulBase + UART_O_LCRH) & UART_LCRH_EPS)
        {
            //
            // Set parity to "Stick One" by clearing the EPS bit.  This call
            // makes sure that stick parity is enabled i.e the SPS and PEN bits
            // in UART Line Control register (UARTLCRH) are both '1'.
            //
            HWREG(ulBase + UART_O_LCRH) = (HWREG(ulBase + UART_O_LCRH) &
                                           (~UART_LCRH_EPS)) | (UART_LCRH_SPS |
                                          UART_LCRH_PEN);
        }

        //
        // Write the 8-bit address to the transmit register.
        //
        HWREG(ulBase + UART_O_DR) = ucAddress;

        //
        // Return Success.
        //
        return true;
    }        
}

//*****************************************************************************
//
//! UART Interrupt handler
//!
//! This UART interrupt handler needs to be called every time you receive a
//! character.  The character is fetched from the UART data register and logic
//! is performed to see if the character was an address or data.  If the
//! character received was an address, the interrupt will compare the address
//! to user address, which was set by using NB_UARTAddressSet().  If the
//! address received is the same as the address of the UART then, all incoming
//! data characters will be added to the receive buffer until an address not
//! equal to the UART address is received.  If the UART address is not received
//! the data will be discarded.
//!
//! This interrupt gives the user an option to call their own interrupt
//! handler function.  If the NB_USER_INT_HANDLER macro is defined, then the
//! NB_UserIntHandler() function will be called in this ISR.
//!
//! \return None.
//
//*****************************************************************************
void
NB_UARTIntHandler(void)
{
    //
    // Check to see if there is an Rx interrupt.
    //
    if((HWREG(g_ulUARTBase + UART_O_RIS) & UART_INT_RX) == UART_INT_RX)
    {
        //
        // Read the UART data from the receive register.
        //
        g_ulRxChar = HWREG(g_ulUARTBase + UART_O_DR);

        //
        // Check if we received an address or data.  We need to look at what
        // the current state of the stick parity is and if there was a parity
        // error.  If the stick parity is set to '0' (i.e EPS = '1') and there
        // was a parity error that means we received an address.  If there was
        // no parity error then a '0' was received which means we received
        // data.  If the stick parity is set to '1' (i.e EPS = '0') and there
        // was no parity error that also means we received an address.  If
        // there was a parity error, then a '0' was received and we received
        // data.  This is summarized in the truth table below.
        //
        //     EPS   |  Parity Error  |   Address or /Data
        // -------------------------------------------------
        //      0    |        0       |          1
        //      0    |        1       |          0
        //      1    |        0       |          0
        //      1    |        1       |          1
        //
        // This comes out to be the following logic functions:
        //              Address = !(EPS ^ Parity Error)
        //              Data    = !(Address)
        //
        if(!(((g_ulRxChar & PARITY_ERROR_BIT) >> 9) ^
           ((HWREG(g_ulUARTBase + UART_O_LCRH) & UART_LCRH_EPS) >> 2)))
        {
            //
            // Check if the address is valid
            //
            if((g_ulRxChar & LS_BYTE_MASK) == g_ucUARTAddress)
            {
                //
                // Set flag to process next piece of UART data.
                //
                g_ulAddressMatchFlag = true;
            }
            else
            {
                //
                // Clear flag to discard next piece of UART data.
                //
                g_ulAddressMatchFlag = false;
            }
        }
        else
        {
            //
            // If the data received was not an address, check if is currently
            // an address match.  If there an address match, add the data to
            // the receive buffer.
            //
            if(g_ulAddressMatchFlag)
            {
                //
                // Add the received data to a buffer.
                //
                RxBufferAdd((g_ulRxChar & LS_BYTE_MASK));
            }
        }
    }

#ifdef NB_USER_INT_HANDLER
    //
    // Call the user int handler if the NB_USER_INT_HANDLER macro is defined.
    //
    NB_UserIntHandler();
#endif

    //
    // Clear all pending interrupts.
    //
    HWREG(g_ulUARTBase + UART_O_ICR) = HWREG(g_ulUARTBase + UART_O_MIS);
}

//*****************************************************************************
//
//! Sets the user programed address.
//!
//! \param ulBase is the base address of the UART port.
//! \param ucAddress is the 8-bit address.
//!
//! Set the address for the UART.  The UART will only process the incoming data
//! after the programmed address is received.  Otherwise, the received data
//! gets discarded.
//!
//! \return None.
//
//*****************************************************************************
void
NB_UARTAddressSet(unsigned long ulBase, unsigned char ucAddress)
{
    //
    // Check the arguments.
    //
    ASSERT(UARTBaseValid(ulBase));

    //
    // Clear the address match flag if the address is not equal to the current
    // address.  This is done so the program knows that the address has
    // changed and there is no longer an address match.
    //
    if(g_ucUARTAddress != ucAddress)
    {
        g_ulAddressMatchFlag = false;
    }

    //
    // Set Address.
    //
    g_ucUARTAddress = ucAddress;
}

//*****************************************************************************
//
//! Returns the user programmed address.
//!
//! \param ulBase is the base address of the UART port.
//!
//! Returns the 8-bit address in an unsigned long format.
//!
//! \return Returns the character address for the specified port, cast as an
//! \e unsigned long.
//
//*****************************************************************************
unsigned long
NB_UARTAddressGet(unsigned long ulBase)
{
    //
    // Check the arguments.
    //
    ASSERT(UARTBaseValid(ulBase));

    //
    // Return the programmable UART address.
    //
    return ((unsigned long)g_ucUARTAddress);
}

//*****************************************************************************
//
//! Determines whether the UART transmitter is busy or not.
//!
//! \param ulBase is the base address of the UART port.
//!
//! Allows the caller to determine whether all transmitted bytes have cleared
//! the transmitter hardware.  If \b false is returned, the transmit register
//! is empty and all bits of the last transmitted character, including all stop
//! bits, have left the hardware shift register.
//!
//! \return Returns \b true if the UART is transmitting or \b false if all
//! transmissions are complete.
//
//*****************************************************************************
tBoolean
NB_UARTBusy(unsigned long ulBase)
{
    //
    // Check the argument.
    //
    ASSERT(UARTBaseValid(ulBase));

    //
    // Return the busy status of the UART.
    //
    return((HWREG(ulBase + UART_O_FR) & UART_FR_BUSY) ? true : false);
}

//*****************************************************************************
//
// Close the Doxygen group.
//! @}
//
//*****************************************************************************
